//PRVI POD 5
typedef void (*VOIDFUN)();

VOIDFUN myfactory(char const* libname, int* size_needed);