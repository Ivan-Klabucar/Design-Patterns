#PRVI PYTHON
class Tiger:
    def __init__(self, name):
        self.name_ = name
    
    def name(self):
        return self.name_
    
    def greet(self):
        return 'Mijau!'
    
    def menu(self):
        return 'mlako mlijeko.'