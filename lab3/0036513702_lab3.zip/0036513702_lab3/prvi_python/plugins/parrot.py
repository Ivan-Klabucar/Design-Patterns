#PRVI PYTHON
class Parrot:
    def __init__(self, name):
        self.name_ = name
    
    def name(self):
        return self.name_
    
    def greet(self):
        return 'Sto mu gromova!'
    
    def menu(self):
        return 'brazilske orahe.'